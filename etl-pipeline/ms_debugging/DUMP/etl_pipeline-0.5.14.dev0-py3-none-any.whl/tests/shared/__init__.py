TEST_ETL_PIPELINE_DATA_PATH = "tests/test_unit/test_etl_pipeline/reference"
TEST_SHARED_DATA_REFERENCE_DIR = "tests/shared/reference"
