from enum import Enum


class AccountType(str, Enum):
    WM_ADDRESS = "WM_ADDRESS"
    ISG_ACCOUNT = "ISG_ACCOUNT"
